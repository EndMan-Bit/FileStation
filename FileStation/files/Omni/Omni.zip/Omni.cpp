﻿#include <iostream>
#include <chrono>
#include <thread>
#include <vector>
//By LiMufan
using namespace std;

int main() {
	string user_name, user_password, user_input;
	bool BpDon = false;
	bool GtnDon = false;
	bool SjbWinDon = false;
	bool SjbTieDon = false;
	bool ErrorDon = false;
	cout << "Omni V5.20261001" << endl;
	this_thread::sleep_for(chrono::seconds(1));
	cout << "登录" << endl;
	cout << "\033[33m用户名:\033[0m";
	cin >> user_name;
	cout << "\033[33m密码:\033[0m";
	cin >> user_password;
	cout << "\033[32m登陆成功!\033[0m" << endl;
	this_thread::sleep_for(chrono::seconds(1));
	cout << "正在初始化用户配置..." << endl;
	this_thread::sleep_for(chrono::seconds(3));
	cout << "================================================================" << endl;
	cout << "欢迎回来!" << user_name << "!" << endl;
	this_thread::sleep_for(chrono::seconds(1));
	cout << "输入(游戏合集)查看所有小游戏" << endl;
	this_thread::sleep_for(chrono::seconds(1));
	cout << "输入(工具合集)查看所有工具" << endl;
	this_thread::sleep_for(chrono::seconds(1));
	cout << "输入(改名)修改用户名" << endl;
	this_thread::sleep_for(chrono::seconds(1));
	cout << "输入(成就)查看已完成或未完成成就" << endl;
	this_thread::sleep_for(chrono::seconds(1));
	cout << "输入(鸣谢名单)看看谁都参与了Omni的制作" << endl;
	this_thread::sleep_for(chrono::seconds(1));
	cout << "输入(更新日志)查看完整更新情况" << endl;
	this_thread::sleep_for(chrono::seconds(1));
	cout << "输入(退出)退出Omni" << endl;
	while (true) {
		cout << "================================================================" << endl;
		cout << user_name << ":";
		cin >> user_input;
		if (user_input == "游戏合集") {
			cout << "截至2026.08.22,已收录3款小游戏" << endl;
			cout << "1.猜数字" << endl;
			cout << "2.解码" << endl;
			cout << "3.石头剪刀布" << endl;
		}
		else if (user_input == "改名") {
			string passwordyes;
			while (true) {
				cout << "输入你的密码:";
				cin >> passwordyes;
				if (passwordyes == user_password) {
					cout << "改名:";
					cin >> user_name;
					cout << "更改云端数据中..." << endl;
					this_thread::sleep_for(chrono::seconds(2));
					break;
				}
				else {
					cout << "密码错误,重新输入!" << endl;
				}
			}
		}
		else if (user_input == "退出") {
			cout << "感谢使用Omni!再见!";
			this_thread::sleep_for(chrono::seconds(2));
			break;
		}
		else if (user_input == "猜数字") {
			int guess_num;
			srand(time(nullptr));
			int rand_num = rand() % 100 + 1;
			while (true) {
				cout << "输入你猜的数字:";
				cin >> guess_num;
				if (guess_num > rand_num) {
					cout << "猜大了!" << endl;
				}
				else if (guess_num < rand_num) {
					cout << "猜小了!" << endl;
				}
				else if (guess_num == rand_num) {
					cout << "猜对了!就是" << rand_num << "!" << endl;
					this_thread::sleep_for(chrono::seconds(2));
					if (GtnDon == false) {
						cout << "成就达成:猜数字小能手!" << endl;
						GtnDon = true;
					}
					break;
				}
			}
		}
		else if (user_input == "解码") {
			cout << "加载中..." << endl;
			this_thread::sleep_for(chrono::seconds(2));
			string BackCode = "I-like-Omni";
			string UserBackCode;
			cout << "原码:L-olnh-Rpql" << endl;
			this_thread::sleep_for(chrono::seconds(1));
			cout << "线索:(a+3)" << endl;
			this_thread::sleep_for(chrono::seconds(1));
			while (true) {
				cout << "请破解他:";
				cin >> UserBackCode;
				if (UserBackCode == BackCode) {
					cout << "太牛了!完全正确!" << endl;
					this_thread::sleep_for(chrono::seconds(2));
					if (BpDon == false) {
						cout << "成就达成:解码大师!" << endl;
						BpDon = true;
					}
					break;
				}
				else {
					cout << "可惜了:(,再好好想想!" << endl;
				}
			}
		}
		else if (user_input == "成就") {
			string GtnAchDon, BpAchDon, SjbWinAchDon, SjbTieAchDon, ErrorAchDon;
			if (GtnDon == true) {
				GtnAchDon = "true";
			}
			else {
				GtnAchDon = "false";
			}
			if (BpDon == true) {
				BpAchDon = "true";
			}
			else {
				BpAchDon = "false";
			}
			if (SjbWinDon == true) {
				SjbWinAchDon = "true";
			}
			else {
				SjbWinAchDon = "false";
			}
			if (SjbTieDon == true) {
				SjbTieAchDon = "true";
			}
			else {
				SjbTieAchDon = "false";
			}
			if (ErrorDon == true) {
				ErrorAchDon = "true";
			}
			else {
				ErrorAchDon = "false";
			}
			cout << "1.我是猜数字小能手-完成状态:" << GtnAchDon << endl;
			cout << "2.解码大师-完成状态:" << BpAchDon << endl;
			cout << "3.人是神-完成状态:" << SjbWinAchDon << endl;
			cout << "4.难得一遇-完成状态:" << SjbTieAchDon << endl;
			cout << "5.没看注意事项是吧-完成状态:" << ErrorAchDon << endl;
		}
		else if (user_input == "石头剪刀布") {
			srand(time(nullptr));
			vector<string> ROBOTSJB = { "石头", "剪刀", "布" };
			string robot_sjb = ROBOTSJB[rand() % 3];
			string player_sjb;
			cout << "加载中..." << endl;
			this_thread::sleep_for(chrono::seconds(2));
			cout << "你将与机器人对战" << endl;
			this_thread::sleep_for(chrono::seconds(1));
			cout << "本游戏采用一局了断方式判断输赢" << endl;
			this_thread::sleep_for(chrono::seconds(2));
			cout << "开始!" << endl;
			this_thread::sleep_for(chrono::seconds(2));
			cout << "你(输入石头/剪刀/布):";
			cin >> player_sjb;
			this_thread::sleep_for(chrono::seconds(1));
			cout << "机器人:" << robot_sjb << endl;
			this_thread::sleep_for(chrono::seconds(1));
			if ((player_sjb == "石头" && robot_sjb == "剪刀") || (player_sjb == "剪刀" && robot_sjb == "布") || (player_sjb == "布" && robot_sjb == "石头")) {
				cout << "恭喜你,你赢了!" << endl;
				this_thread::sleep_for(chrono::seconds(2));
				if (SjbWinDon == false) {
					cout << "成就达成:人是神!" << endl;
					SjbWinDon = true;
				}
			}
			else if (player_sjb == robot_sjb) {
				cout << "平局!" << endl;
				this_thread::sleep_for(chrono::seconds(2));
				if (SjbTieDon == false) {
					cout << "成就达成:难得一遇!" << endl;
					SjbTieDon = true;
				}
			}
			else {
				cout << "很遗憾,你输了!" << endl;
			}
		}
		else if (user_input == "工具合集") {
			cout << "截至目前,已收录2款工具" << endl;
			cout << "1.计算器" << endl;
			cout << "2.阶乘计算" << endl;
		}
		else if (user_input == "更新日志") {
			cout << "V5.20261001" << endl;
			cout << "更新内容:修复已知BUG,提高用户使用效率;删除(鸣谢名单)" << endl;
			this_thread::sleep_for(chrono::seconds(1));
			cout << "V4.20260824" << endl;
			cout << "更新内容:更新了更新日志选项,删除了一个隐藏成就" << endl;
			this_thread::sleep_for(chrono::seconds(1));
			cout << "V3.20260820" << endl;
			cout << "更新内容:更新了成就系统" << endl;
			this_thread::sleep_for(chrono::seconds(1));
			cout << "V2.20260817" << endl;
			cout << "更新内容:修复已知BUG,提高用户使用效率" << endl;
			this_thread::sleep_for(chrono::seconds(1));
			cout << "V1.20260809" << endl;
			cout << "更新日志:这是Omni的第一个版本,很多现在的功能都是这一时期添加的,一天内,不骗你!(*/ω＼*)" << endl;
			this_thread::sleep_for(chrono::seconds(1));
		}
		else {
			cout << "\33[31m无效指令:(\33[0m" << endl;
			if (ErrorDon == false) {
				ErrorDon = true;
			}
		}
	}
	return 0;
}
